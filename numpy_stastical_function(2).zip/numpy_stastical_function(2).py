Python 3.9.8 (tags/v3.9.8:bb3fdcf, Nov  5 2021, 20:48:33) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import numpy as np
>>> x_odd=np.array([1,2,3,4,5,6,7])
>>> median_value=np.median(x_odd)
>>> print(median_value)
4.0
>>> 