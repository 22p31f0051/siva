Python 3.9.8 (tags/v3.9.8:bb3fdcf, Nov  5 2021, 20:48:33) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import numpy as np
>>> category1_revenue=np.array([500,600,700,550])
>>> category2_revenue=np.array([450,700,800,600])
>>> total_revenue=category1_revenue+category2_revenue
>>> print("Total revenue: ",total_revenue)
Total revenue:  [ 950 1300 1500 1150]
>>> 