Python 3.9.8 (tags/v3.9.8:bb3fdcf, Nov  5 2021, 20:48:33) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import numpy as np
>>> my_list=[1,2,3,4,5,6,7,8]
>>> my_tuple=([8,4,6],[1,2,3])
>>> array_list=np.array()
Traceback (most recent call last):
  File "<pyshell#3>", line 1, in <module>
    array_list=np.array()
TypeError: array() missing required argument 'object' (pos 0)
>>> array_list=np.array(my_list)
>>> arrat_tuple=np.array(my_tuple)
>>> print("Array from list",my_list)
Array from list [1, 2, 3, 4, 5, 6, 7, 8]
>>> print("Array from tuple",my_tuple)
Array from tuple ([8, 4, 6], [1, 2, 3])
>>> 