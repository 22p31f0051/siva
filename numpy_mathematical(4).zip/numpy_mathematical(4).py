Python 3.9.8 (tags/v3.9.8:bb3fdcf, Nov  5 2021, 20:48:33) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import numpy as np
>>> quantity=np.array([2,3,4,1])
>>> price_per_item=np.array([10.0,5.0,8.0,12.0])
>>> Total_cost=quantity*price_per_item
>>> print(total_cost)
Traceback (most recent call last):
  File "<pyshell#4>", line 1, in <module>
    print(total_cost)
NameError: name 'total_cost' is not defined
>>> print(Total_cost)
[20. 15. 32. 12.]
>>> 