Python 3.9.8 (tags/v3.9.8:bb3fdcf, Nov  5 2021, 20:48:33) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import numpy as np
>>> inventory=np.array([10,0,5,0,20,0])
>>> out_of_stock=inventory[inventory==0]
>>> print("Out of stock products:",out_of_stock)
Out of stock products: [0 0 0]
>>> 