Python 3.9.8 (tags/v3.9.8:bb3fdcf, Nov  5 2021, 20:48:33) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import numpy as np
>>> revenue=np.array([10000,12000,11000,10500])
>>> expences=np.array([4000,5000,4500,4800])
>>> profit=revenue-expences
>>> print("Profit:"profit)
SyntaxError: invalid syntax
>>> print("Profit:",profit)
Profit: [6000 7000 6500 5700]
>>> 