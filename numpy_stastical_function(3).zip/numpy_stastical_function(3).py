Python 3.9.8 (tags/v3.9.8:bb3fdcf, Nov  5 2021, 20:48:33) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import numpy as np
>>> arr=[20,2,7,1,34]
>>> std=np.array(arr)
>>> mean=np.mean(std)
>>> print(mean)
12.8
>>> stdd=np.std(std)
>>> print(stdd)
12.576167937809991
>>> 