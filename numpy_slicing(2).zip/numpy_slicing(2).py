Python 3.9.8 (tags/v3.9.8:bb3fdcf, Nov  5 2021, 20:48:33) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import numpy as np
>>> matrix= np.arange(2,11).reshape(3,3)
>>> print("3*3 matrix with values from 2 to 10",matrix)
3*3 matrix with values from 2 to 10 [[ 2  3  4]
 [ 5  6  7]
 [ 8  9 10]]
>>> 