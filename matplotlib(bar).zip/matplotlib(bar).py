Python 3.9.8 (tags/v3.9.8:bb3fdcf, Nov  5 2021, 20:48:33) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import matplotlib.pyplot as plt
>>> genres = ["mystery", "romance", "comedy", "horror", "thriller"]
>>> books_sold = [120,150,820,250,450]
>>> plt.bar(grnres,books_sold)
Traceback (most recent call last):
  File "<pyshell#3>", line 1, in <module>
    plt.bar(grnres,books_sold)
NameError: name 'grnres' is not defined
>>> plt.bar(genres,books_sold)
<BarContainer object of 5 artists>
>>> plt.xlabel("Genre")
Text(0.5, 0, 'Genre')
>>> plt.ylabel("Number of books sold")
Text(0, 0.5, 'Number of books sold')
>>> plt.title("Books sold by genre")
Text(0.5, 1.0, 'Books sold by genre')
>>> plt.show()
