Python 3.9.8 (tags/v3.9.8:bb3fdcf, Nov  5 2021, 20:48:33) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import matplotlib.pyplot as plt
>>> import pandas as pd
>>> data={
	'Date': pd.date_range(start='2020-01-01', periods='12', freq='M'),
	'Region_A': [100,120,140,160,180,200,220,240,260,280,300,320],
	'Region_B': [80,95,110,125,140,160,175,190,210,230,250,270],
	'Region_B': [90,110,130,150,170,190,210,230,250,270,290,310]
	}
Traceback (most recent call last):
  File "<pyshell#7>", line 2, in <module>
    'Date': pd.date_range(start='2020-01-01', periods='12', freq='M'),
  File "C:\Users\Siva\AppData\Local\Programs\Python\Python39\lib\site-packages\pandas\core\indexes\datetimes.py", line 1008, in date_range
    dtarr = DatetimeArray._generate_range(
  File "C:\Users\Siva\AppData\Local\Programs\Python\Python39\lib\site-packages\pandas\core\arrays\datetimes.py", line 412, in _generate_range
    periods = dtl.validate_periods(periods)
  File "C:\Users\Siva\AppData\Local\Programs\Python\Python39\lib\site-packages\pandas\core\arrays\datetimelike.py", line 2504, in validate_periods
    raise TypeError(f"periods must be a number, got {periods}")
TypeError: periods must be a number, got 12
>>> data={
	'Date': pd.date_range(start='2020-01-01', periods=12, freq='M'),
	'Region_A': [100,120,140,160,180,200,220,240,260,280,300,320],
	'Region_B': [80,95,110,125,140,160,175,190,210,230,250,270],
	'Region_B': [90,110,130,150,170,190,210,230,250,270,290,310]
	}

Warning (from warnings module):
  File "<pyshell#8>", line 2
FutureWarning: 'M' is deprecated and will be removed in a future version, please use 'ME' instead.
>>> data={
	'Date': pd.date_range(start='2020-01-01', periods=12, freq='ME'),
	'Region_A': [100,120,140,160,180,200,220,240,260,280,300,320],
	'Region_B': [80,95,110,125,140,160,175,190,210,230,250,270],
	'Region_B': [90,110,130,150,170,190,210,230,250,270,290,310]
	}
>>> df= pd.DataFrame(data)
>>> fig, axs=plt.subplots(3,1, figsize=(10,10), sharex=True)
>>> axs[0].plot(df['Date'],df['Region_A'],color='green',label='Region A')
[<matplotlib.lines.Line2D object at 0x0000024AD8357F40>]
>>> axs[0].set_title('Sales in Region A')
Text(0.5, 1.0, 'Sales in Region A')
>>> axs[0].set_ylabel('sales')
Text(0, 0.5, 'sales')
>>> axs[0].legend()
<matplotlib.legend.Legend object at 0x0000024AD8357DF0>
>>> axs[1].plot(df['Date'],df['Region_B'],color='red',label='Region B')
[<matplotlib.lines.Line2D object at 0x0000024AD8357E50>]
>>> axs[1].set_title('Sales in Region B')
Text(0.5, 1.0, 'Sales in Region B')
>>> axs[1].set_ylabel('Sales')
Text(0, 0.5, 'Sales')
>>> axs[1].legend()
<matplotlib.legend.Legend object at 0x0000024AD830A1F0>
>>> axs[2].plot(df['Date'],df['Region_B'],color='blue',label='Region C')
[<matplotlib.lines.Line2D object at 0x0000024AD7247DC0>]
>>> axs[2].set_title('Sales in Region C')
Text(0.5, 1.0, 'Sales in Region C')
>>> axs[2].set_ylabel('Sales')
Text(0, 0.5, 'Sales')
>>> axs[2].legend()
<matplotlib.legend.Legend object at 0x0000024AD8347070>
>>> plt.xlabel('Time')
Text(0.5, 0, 'Time')
>>> plt.show()
