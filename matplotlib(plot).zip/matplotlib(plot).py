Python 3.9.8 (tags/v3.9.8:bb3fdcf, Nov  5 2021, 20:48:33) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import matplotlib.pyplot as plt
>>> days=list(range(1.31))
Traceback (most recent call last):
  File "<pyshell#1>", line 1, in <module>
    days=list(range(1.31))
TypeError: 'float' object cannot be interpreted as an integer
>>> days=list(range(1,31))
>>> temparatures=[60,52,78,52,25,45,23,12,45,85,65,45,23,45,89,35,75,15,59,95,51,45,45,85,75,65,45,54,46,23,51]
>>> plt.plot(days,temparature,marker='o')
Traceback (most recent call last):
  File "<pyshell#4>", line 1, in <module>
    plt.plot(days,temparature,marker='o')
NameError: name 'temparature' is not defined
>>> plt.xlabel("Days of the month")
Text(0.5, 0, 'Days of the month')
>>> plt.ylabel("Temperature(F)")
Text(0, 0.5, 'Temperature(F)')
>>> plt.title("Daily temperatures Over a month")
Text(0.5, 1.0, 'Daily temperatures Over a month')
>>> plt.show()
