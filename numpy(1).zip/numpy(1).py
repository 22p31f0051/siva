Python 3.9.8 (tags/v3.9.8:bb3fdcf, Nov  5 2021, 20:48:33) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import numpy as np
>>> my_list=[1,2,3,4,5]
>>> my_array=np.array(my_list)
>>> print("Numpy array:",my_array)
Numpy array: [1 2 3 4 5]
>>> 