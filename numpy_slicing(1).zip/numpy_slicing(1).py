Python 3.9.8 (tags/v3.9.8:bb3fdcf, Nov  5 2021, 20:48:33) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import numpy as np
>>> zeros_arry= np.zeros(10)
>>> ones_array=np.ones(10)
>>> fives_array=np.full(10,5)
>>> result=np.concatenate((zeros_arry,ones_array,fives_array))
>>> print("Array of 10 zeros,10 ones, 10 fives:",result)
Array of 10 zeros,10 ones, 10 fives: [0. 0. 0. 0. 0. 0. 0. 0. 0. 0. 1. 1. 1. 1. 1. 1. 1. 1. 1. 1. 5. 5. 5. 5.
 5. 5. 5. 5. 5. 5.]
>>> 