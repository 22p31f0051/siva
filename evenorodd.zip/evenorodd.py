Python 3.9.8 (tags/v3.9.8:bb3fdcf, Nov  5 2021, 20:48:33) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> number = 10
>>> result= "Even" if number %2 == 0 else "Odd"
>>> print(f"The number {number} is {result})
      
SyntaxError: EOL while scanning string literal
>>> print(f"The number {number} is {result}")
The number 10 is Even
>>> 